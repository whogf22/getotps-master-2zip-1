-- ========================================
-- ADD EMAIL/SMTP FUNCTIONALITY
-- ========================================
-- Run this SQL on your existing database to add email/SMTP support
-- Safe to run - uses INSERT IGNORE to avoid duplicates
-- ========================================

-- Create email templates table if it doesn't exist
CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `body` TEXT NOT NULL,
  `variables` TEXT NULL COMMENT 'JSON array of available variables',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default email templates
INSERT IGNORE INTO `email_templates` (`name`, `subject`, `body`, `variables`, `created_at`) VALUES
('welcome', 'Welcome to {{site_name}}!', 
'<h2>Welcome {{user_name}}!</h2>\n<p>Thank you for joining {{site_name}}. Your account has been created successfully.</p>\n<p>You can now log in and start using our services.</p>\n<p>If you have any questions, feel free to contact our support team.</p>\n<p>Best regards,<br>{{site_name}} Team</p>', 
'["user_name","site_name","login_url"]', NOW()),

('low_balance', 'Low Balance Alert - {{site_name}}', 
'<h2>Low Balance Alert</h2>\n<p>Hello {{user_name}},</p>\n<p>Your account balance is running low: <strong>{{balance}}</strong></p>\n<p>Please add funds to your account to continue using our services without interruption.</p>\n<p><a href="{{add_funds_url}}">Add Funds Now</a></p>\n<p>Best regards,<br>{{site_name}} Team</p>', 
'["user_name","balance","add_funds_url","site_name"]', NOW()),

('activation_completed', 'Number Activated Successfully - {{site_name}}', 
'<h2>Activation Completed</h2>\n<p>Hello {{user_name}},</p>\n<p>Your number <strong>{{number}}</strong> for service <strong>{{service}}</strong> has been activated successfully!</p>\n<p>SMS Code: <strong>{{code}}</strong></p>\n<p>Thank you for using our service.</p>\n<p>Best regards,<br>{{site_name}} Team</p>', 
'["user_name","number","service","code","site_name"]', NOW()),

('admin_new_user', 'New User Registration - {{site_name}}', 
'<h2>New User Registered</h2>\n<p>A new user has registered on {{site_name}}:</p>\n<ul>\n<li>Name: {{user_name}}</li>\n<li>Email: {{user_email}}</li>\n<li>Role: {{user_role}}</li>\n<li>Registration Date: {{registration_date}}</li>\n</ul>\n<p>View user details in the admin panel.</p>', 
'["user_name","user_email","user_role","registration_date","site_name"]', NOW()),

('password_reset', 'Password Reset Request - {{site_name}}', 
'<h2>Password Reset Request</h2>\n<p>Hello {{user_name}},</p>\n<p>We received a request to reset your password. Click the link below to reset it:</p>\n<p><a href="{{reset_link}}">Reset Password</a></p>\n<p>This link will expire in 1 hour.</p>\n<p>If you did not request this reset, please ignore this email.</p>\n<p>Best regards,<br>{{site_name}} Team</p>', 
'["user_name","reset_link","site_name"]', NOW());

-- Insert SMTP settings into settings table
INSERT IGNORE INTO `settings` (`key`, `value`, `updated_at`) VALUES
('mail_smtp_enabled', '0', NOW()),
('mail_smtp_host', '', NOW()),
('mail_smtp_port', '587', NOW()),
('mail_smtp_username', '', NOW()),
('mail_smtp_password', '', NOW()),
('mail_smtp_encryption', 'tls', NOW()),
('mail_smtp_auth', '1', NOW()),
('mail_from_address', '', NOW()),
('mail_from_name', 'SMS Reseller Platform', NOW()),
('mail_signup_enabled', '1', NOW()),
('mail_low_balance_enabled', '1', NOW()),
('mail_activation_enabled', '1', NOW());

-- ========================================
-- MIGRATION COMPLETE!
-- ========================================
-- Next steps:
-- 1. Go to Admin Dashboard > Settings
-- 2. Configure your SMTP settings
-- 3. Click "Send Test Email" to verify
-- ========================================
