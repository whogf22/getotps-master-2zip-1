-- Add email subscription preference to users table
-- This allows users to unsubscribe from bulk emails

ALTER TABLE `users` 
ADD COLUMN `email_subscribed` TINYINT(1) NOT NULL DEFAULT 1 AFTER `api_token`,
ADD KEY `email_subscribed` (`email_subscribed`);

-- Note: By default all users are subscribed (1 = subscribed, 0 = unsubscribed)
-- This only affects bulk/marketing emails, not transactional emails like receipts or password resets
