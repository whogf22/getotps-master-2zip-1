-- Proxnum Reseller Database Schema
-- Version 1.0.0

-- Users table (both admins and clients)
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('admin', 'client') NOT NULL DEFAULT 'client',
  `balance` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `status` ENUM('active', 'suspended', 'inactive') NOT NULL DEFAULT 'active',
  `reseller_id` INT(11) UNSIGNED NULL,
  `api_token` VARCHAR(255) NULL,
  `email_subscribed` TINYINT(1) NOT NULL DEFAULT 1,
  `last_login` DATETIME NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `reseller_id` (`reseller_id`),
  KEY `status` (`status`),
  KEY `role` (`role`),
  KEY `email_subscribed` (`email_subscribed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Transactions table  
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED NOT NULL,
  `type` ENUM('credit', 'debit', 'purchase', 'refund') NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `balance_before` DECIMAL(10,2) NOT NULL,
  `balance_after` DECIMAL(10,2) NOT NULL,
  `description` TEXT NULL,
  `reference` VARCHAR(255) NULL,
  `created_by` INT(11) UNSIGNED NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `type` (`type`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `fk_trans_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Virtual number activations table
CREATE TABLE IF NOT EXISTS `activations` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED NOT NULL,
  `activation_id` VARCHAR(255) NOT NULL,
  `service` VARCHAR(50) NOT NULL,
  `country` VARCHAR(10) NOT NULL,
  `phone` VARCHAR(50) NOT NULL,
  `code` VARCHAR(20) NULL,
  `status` ENUM('pending', 'completed', 'cancelled', 'expired') NOT NULL DEFAULT 'pending',
  `cost` DECIMAL(10,2) NOT NULL,
  `proxnum_response` TEXT NULL,
  `created_at` DATETIME NOT NULL,
  `completed_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `activation_id` (`activation_id`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `fk_act_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rentals table
CREATE TABLE IF NOT EXISTS `rentals` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED NOT NULL,
  `rental_id` VARCHAR(255) NOT NULL,
  `service` VARCHAR(50) NOT NULL,
  `country` VARCHAR(10) NOT NULL,
  `phone` VARCHAR(50) NOT NULL,
  `days` INT(3) NOT NULL,
  `status` ENUM('active', 'cancelled', 'expired') NOT NULL DEFAULT 'active',
  `cost` DECIMAL(10,2) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `proxnum_response` TEXT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `rental_id` (`rental_id`),
  KEY `status` (`status`),
  KEY `expires_at` (`expires_at`),
  CONSTRAINT `fk_rent_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rental messages table
CREATE TABLE IF NOT EXISTS `rental_messages` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `rental_id` INT(11) UNSIGNED NOT NULL,
  `sender` VARCHAR(50) NOT NULL,
  `message` TEXT NOT NULL,
  `received_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rental_id` (`rental_id`),
  KEY `received_at` (`received_at`),
  CONSTRAINT `fk_msg_rental` FOREIGN KEY (`rental_id`) REFERENCES `rentals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Email Templates table
CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `body` TEXT NOT NULL,
  `variables` TEXT NULL COMMENT 'JSON array of available variables',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Settings table
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `key` VARCHAR(255) NOT NULL,
  `value` TEXT NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- License verification cache
CREATE TABLE IF NOT EXISTS `license_cache` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `license_key` VARCHAR(255) NOT NULL,
  `verified_at` DATETIME NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `data` TEXT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Activity logs
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED NULL,
  `action` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` TEXT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Support tickets table
CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED NOT NULL,
  `ticket_number` VARCHAR(50) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `priority` ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
  `status` ENUM('open', 'pending', 'resolved', 'closed') NOT NULL DEFAULT 'open',
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_number` (`ticket_number`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `fk_ticket_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Support ticket replies table
CREATE TABLE IF NOT EXISTS `support_replies` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ticket_id` INT(11) UNSIGNED NOT NULL,
  `user_id` INT(11) UNSIGNED NOT NULL,
  `message` TEXT NOT NULL,
  `is_admin` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `user_id` (`user_id`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `fk_reply_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_reply_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default settings
INSERT INTO `settings` (`key`, `value`, `updated_at`) VALUES
('site_name', 'Proxnum Reseller', NOW()),
('site_logo', '', NOW()),
('maintenance_mode', '0', NOW()),
('default_markup', '0', NOW()),
('allow_registration', '0', NOW()),
('min_balance', '1.00', NOW()),
-- Email/SMTP Settings
('mail_smtp_enabled', '0', NOW()),
('mail_smtp_host', '', NOW()),
('mail_smtp_port', '587', NOW()),
('mail_smtp_username', '', NOW()),
('mail_smtp_password', '', NOW()),
('mail_smtp_encryption', 'tls', NOW()),
('mail_smtp_auth', '1', NOW()),
('mail_from_address', '', NOW()),
('mail_from_name', 'SMS Reseller Platform', NOW()),
('mail_signup_enabled', '1', NOW()),
('mail_low_balance_enabled', '1', NOW()),
('mail_activation_enabled', '1', NOW());

-- Insert default email templates
INSERT INTO `email_templates` (`name`, `subject`, `body`, `variables`, `created_at`) VALUES
('welcome', 'Welcome to {{site_name}}!', 
'<h2>Welcome {{user_name}}!</h2>\n<p>Thank you for joining {{site_name}}. Your account has been created successfully.</p>\n<p>You can now log in and start using our services.</p>\n<p>If you have any questions, feel free to contact our support team.</p>\n<p>Best regards,<br>{{site_name}} Team</p>', 
'["user_name","site_name","login_url"]', NOW()),

('low_balance', 'Low Balance Alert - {{site_name}}', 
'<h2>Low Balance Alert</h2>\n<p>Hello {{user_name}},</p>\n<p>Your account balance is running low: <strong>{{balance}}</strong></p>\n<p>Please add funds to your account to continue using our services without interruption.</p>\n<p><a href="{{add_funds_url}}">Add Funds Now</a></p>\n<p>Best regards,<br>{{site_name}} Team</p>', 
'["user_name","balance","add_funds_url","site_name"]', NOW()),

('activation_completed', 'Number Activated Successfully - {{site_name}}', 
'<h2>Activation Completed</h2>\n<p>Hello {{user_name}},</p>\n<p>Your number <strong>{{number}}</strong> for service <strong>{{service}}</strong> has been activated successfully!</p>\n<p>SMS Code: <strong>{{code}}</strong></p>\n<p>Thank you for using our service.</p>\n<p>Best regards,<br>{{site_name}} Team</p>', 
'["user_name","number","service","code","site_name"]', NOW()),

('admin_new_user', 'New User Registration - {{site_name}}', 
'<h2>New User Registered</h2>\n<p>A new user has registered on {{site_name}}:</p>\n<ul>\n<li>Name: {{user_name}}</li>\n<li>Email: {{user_email}}</li>\n<li>Role: {{user_role}}</li>\n<li>Registration Date: {{registration_date}}</li>\n</ul>\n<p>View user details in the admin panel.</p>', 
'["user_name","user_email","user_role","registration_date","site_name"]', NOW()),

('password_reset', 'Password Reset Request - {{site_name}}', 
'<h2>Password Reset Request</h2>\n<p>Hello {{user_name}},</p>\n<p>We received a request to reset your password. Click the link below to reset it:</p>\n<p><a href="{{reset_link}}">Reset Password</a></p>\n<p>This link will expire in 1 hour.</p>\n<p>If you did not request this reset, please ignore this email.</p>\n<p>Best regards,<br>{{site_name}} Team</p>', 
'["user_name","reset_link","site_name"]', NOW());
