# Proxnum Reseller - Complete Installation & Usage Guide

## 📦 Installation Guide

### System Requirements

Before installing, ensure your server meets these requirements:

- **PHP**: 7.4 or higher
- **MySQL/MariaDB**: 5.7+ / 10.3+
- **Web Server**: Apache with mod_rewrite OR Nginx
- **PHP Extensions**:
  - mysqli or pdo_mysql
  - curl
  - json
  - openssl
  - mbstring

### Step-by-Step Installation

#### 1. Upload Files

1. Download the `proxnum-reseller.zip` file
2. Upload to your hosting account via FTP or File Manager
3. Extract the zip file in your root directory (e.g., `public_html` or `www`)

#### 2. Set Permissions

Set the following folders to writable (755 or 775):
```
- /config
- /logs
- /cache
```

#### 3. Run Installer

1. Navigate to `http://yourdomain.com/install` in your browser
2. The installer will check system requirements automatically
3. Follow the wizard steps:

**Step 1: Requirements Check**
- All requirements must pass before proceeding

**Step 2: License & API Configuration**
- Enter your license key (format: XXXX-XXXX-XXXX-XXXX)
- Enter your Proxnum API key (from your Proxnum profile)
- Enter the email associated with your license

**Step 3: Database Configuration**
- Database Host: Usually `localhost`
- Database Name: Create a new database first
- Database Username: Your MySQL username
- Database Password: Your MySQL password

**Step 4: Admin Account**
- Create your admin login credentials
- Use a strong password (minimum 8 characters)

**Step 5: Complete**
- Installation will create all necessary tables and files
- **IMPORTANT**: Delete the `/install` folder immediately after installation

#### 4. Secure Your Installation

After installation:
```bash
# Delete installer (REQUIRED)
rm -rf /install

# Set correct permissions
chmod 644 .htaccess
chmod 644 index.php
chmod 755 logs cache
```

---

## 🔑 Getting Your License Key

### Purchase License

1. Visit [proxnum.com](https://proxnum.com)
2. Navigate to **Reseller Program** → **Licenses**
3. Choose your plan:
   - **Monthly**: $20/month - Billed monthly, cancel anytime
   - **Lifetime**: $300 one-time - Pay once, use forever

### License Types

**Monthly License**
- $20 per month
- Automatic renewal
- Cancel anytime
- Full features

**Lifetime License**
- $300 one-time payment
- No recurring fees
- Lifetime updates
- Priority support

### Activation

1. After purchase, you'll receive your license key via email
2. Format: `XXXX-XXXX-XXXX-XXXX`
3. Use this key during installation
4. The system verifies your license every 24 hours

---

## 🚀 Getting Your Proxnum API Key

### Generate API Key

1. Login to your Proxnum account: [proxnum.com/login](https://proxnum.com/login)
2. Go to **Profile** → **API Keys**
3. Click **Generate New API Key**
4. Copy the API key immediately (you won't see it again)
5. Store it securely

### API Key Requirements

- You must have an active Proxnum account
- Your Proxnum account must have sufficient balance
- Keep your API key secret - never share it
- Regenerate if compromised

---

## 👨‍💼 Admin Panel Guide

### First Login

After installation:
- URL: `http://yourdomain.com/auth/login`
- Use admin credentials from installation

### Admin Dashboard

The admin dashboard shows:
- Total clients count
- Active clients
- Total activations
- Pending activations
- Total client balance
- Today's revenue
- Recent clients
- Recent transactions

### Managing Clients

#### Add New Client

1. Go to **Clients** → **Add New Client**
2. Enter client details:
   - Full Name
   - Email Address
   - Password
   - Initial Balance (optional)
3. Click **Create Client**
4. Send credentials to client

#### Add Balance to Client

1. Go to **Clients**
2. Find the client
3. Click **Add Balance**
4. Enter amount and description
5. Client can now use this balance to purchase numbers

#### Change Client Status

**Status Types:**
- **Active**: Client can login and use the system
- **Suspended**: Client cannot make purchases (temporary)
- **Inactive**: Client cannot login (permanent)

To change status:
1. Go to **Clients**
2. Find the client
3. Click **Status**
4. Select new status

### View Transactions

All financial activities are logged:
- Balance credits by admin
- Number purchases by clients
- Refunds
- Debits

Filter by:
- Date range
- Client
- Transaction type

### Settings

Configure system settings:
- **Site Name**: Your company name
- **Allow Registration**: Enable/disable public signup
- **Minimum Balance**: Minimum balance for purchases
- **Default Markup**: Your profit margin (future feature)

---

## 👤 Client Dashboard Guide

### Client Login

- URL: `http://yourdomain.com/auth/login`
- Use credentials provided by admin

### Dashboard Overview

Shows:
- Current balance
- Total activations
- Pending activations
- Active rentals

### Buying a Number

1. Click **Buy Number**
2. Select **Service** (WhatsApp, Telegram, etc.)
3. Select **Country**
4. System shows price and availability
5. Click **Purchase Number**
6. You'll be redirected to activation details

### Viewing Activations

**Activation Statuses:**
- **Pending**: Waiting for SMS code
- **Completed**: Code received
- **Cancelled**: Activation cancelled
- **Expired**: Timeout without code

**Auto-Refresh:**
- Pending activations auto-check for codes
- Page refreshes when code arrives
- No manual refresh needed

### Checking SMS Code

1. Go to **Activations**
2. Click on an activation
3. The SMS code will appear when received
4. Use the code in your application
5. Copy code with one click

### Cancelling Activation

- Only **pending** activations can be cancelled
- Partial refund may apply (based on Proxnum policy)
- Click **Cancel** on activation page

### Transaction History

View all your transactions:
- Balance additions
- Number purchases
- Refunds
- Current balance after each transaction

---

## 🔒 Security Features

### License Protection

- Verified every 24 hours with central server
- 72-hour grace period if server unreachable
- Cannot be used with invalid license
- Domain-locked to your installation

### Code Security

**Encrypted Files:**
- Core system files use ionCube encryption
- License verification cannot be bypassed
- API integration is protected

**Database Security:**
- All queries use prepared statements
- SQL injection protection
- XSS prevention on all inputs

**Session Security:**
- Secure session handling
- CSRF token protection
- Password hashing with bcrypt

**API Security:**
- API key encrypted in database
- Secure communication with Proxnum
- Request validation

### Best Practices

1. **Keep License Active**: Don't let it expire
2. **Update Regularly**: Install updates when available
3. **Backup Database**: Daily automated backups recommended
4. **Strong Passwords**: Enforce for all users
5. **HTTPS**: Use SSL certificate (highly recommended)
6. **Monitor Logs**: Check `/logs` folder regularly

---

## 🐛 Troubleshooting

### Installation Issues

**"Requirements Not Met"**
- Contact hosting provider
- Ask to enable required PHP extensions
- Upgrade PHP version if needed

**"Database Connection Failed"**
- Verify database credentials
- Ensure database exists
- Check database user permissions

**"License Verification Failed"**
- Verify license key format
- Check internet connectivity
- Ensure license is active

### Runtime Issues

**"License Error"**
- License may have expired
- Contact support to renew
- Check cache folder permissions

**"Insufficient Balance"**
- Client needs more funds
- Admin must add balance
- Check Proxnum account balance

**"Purchase Failed"**
- Check Proxnum API status
- Verify service/country availability
- Ensure API key is valid

**"Page Not Found"**
- Check .htaccess file exists
- Verify mod_rewrite is enabled
- Review Apache configuration

### Log Files

Check these logs for errors:
- `/logs/error.log` - PHP errors
- `/logs/activity.log` - User actions
- Apache error logs

---

## 📞 Support

### Before Contacting Support

1. Check this guide
2. Review error logs
3. Verify system requirements
4. Test on different browser

### Contact Information

- **Email**: support@proxnum.com
- **Website**: [proxnum.com](https://proxnum.com)
- **Documentation**: This file

### What to Include

When requesting support:
- License key
- Error message (exact text)
- Steps to reproduce
- PHP version
- Server environment

---

## 🔄 Updates

### Checking for Updates

1. Login to admin panel
2. Check for update notification
3. Download latest version
4. Read CHANGELOG.md

### Updating System

1. **Backup First** (critical!)
   ```bash
   # Backup database
   mysqldump -u username -p database_name > backup.sql
   
   # Backup files
   tar -czf backup.tar.gz .
   ```

2. **Download Update**
   - Get latest version
   - Extract files

3. **Replace Files**
   - Keep `/config` folder (don't replace)
   - Replace all other files
   - Check `/install/update.php` for migration

4. **Run Update Script** (if exists)
   - Navigate to `/update.php`
   - Follow instructions
   - Delete update script after

5. **Test Everything**
   - Test login
   - Test purchases
   - Check all features

---

## ⚖️ License Agreement

### Terms of Use

By using this software:

1. **License Required**: Valid license key mandatory
2. **No Redistribution**: Cannot resell or share software
3. **No Reverse Engineering**: Cannot crack or modify encrypted files
4. **One Domain**: License valid for one domain only
5. **Support**: Provided for licensed users only

### Prohibited Actions

- Removing license checks
- Sharing license keys
- Using nulled/cracked versions
- Decompiling encrypted files
- Reselling the software itself

### Violations

License violations may result in:
- Immediate license termination
- No refund
- Legal action
- Account suspension

---

## 💡 Tips for Success

### For Resellers

1. **Price Competitively**: Add reasonable markup
2. **Provide Support**: Help your clients fast
3. **Maintain Balance**: Keep Proxnum account funded
4. **Monitor Usage**: Check daily statistics
5. **Build Trust**: Deliver quality service

### For Clients

1. **Add Sufficient Balance**: Avoid interruptions
2. **Act Fast on Codes**: SMS codes expire
3. **Check Service Availability**: Before purchasing
4. **Contact Admin**: For balance or issues

---

##  API Endpoints (For Developers)

If you need to integrate with external systems:

### Get Balance
```
GET /api/balance
Header: Authorization: Bearer {user_api_token}
```

### Purchase Number
```
POST /api/purchase
Body: {service, country}
Header: Authorization: Bearer {user_api_token}
```

*Contact support for full API documentation*

---

## 🎯 Roadmap

Planned features:
-  Virtual number activations
-  License system
-  Admin panel
-  Client dashboard
- 🔄 Rental phone numbers (in progress)
- 📱 Mobile app
- 💳 Payment gateway integration
-  Advanced analytics
- 🌐 Multi-language support
- 🎨 Theme customization

---

**Version**: 1.0.0  
**Last Updated**: February 2026  
**Developed for Proxnum**

© 2026 Proxnum. All rights reserved.
